import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class CountRecsReducer extends Reducer<Text, IntWritable, Text, IntWritable> {

    @Override
    public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        int rec_c = 0;
        for (IntWritable value: values) {
            rec_c += value.get();
        }

        String o = "Total number of records in my dataset: ";
        context.write(new Text(o), new IntWritable(rec_c));

    }
}
