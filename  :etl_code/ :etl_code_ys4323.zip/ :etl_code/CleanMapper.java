import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class CleanMapper extends Mapper<LongWritable, Text, Text, Text> {

    private static final int MISSING = 9999;

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        String line = value.toString();
        String[] lineStore = line.split(",");

        if (lineStore.length >= 9 && !lineStore[0].contains("NAICS")) {
            ArrayList<String> newStore = new ArrayList<String>();
            Pattern pattern = Pattern.compile(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

            try (Scanner scanner = new Scanner(line).useDelimiter(pattern)) {
                while (scanner.hasNext()) {
                    String element = scanner.next().replace(",", "").replaceAll("\"", "").trim();
                    newStore.add(element);
                }
            }

            String sector = newStore.get(0);
            String cleanones = "";

            for (int i = 2; i < newStore.size(); i++) {

                    double a = Double.parseDouble(newStore.get(i));
                    if (a > 1) {
                        if (i == newStore.size() - 1) {
                            cleanones += newStore.get(i);
                        } else {
                            cleanones += newStore.get(i) + ",";
                        
                    }
                }
            }

            context.write(new Text(sector), new Text(cleanones));
        }
    }
}
